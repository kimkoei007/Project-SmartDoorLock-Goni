/**
 * Copied from https://code.google.com/p/mobile-anarchy-widgets/
 */
package org.droidplanner.android.widgets.joystick;

public interface JoystickClickedListener {
	public void OnClicked();

	public void OnReleased();
}
