/**
 * Contains code and logic used to access the core classes.
 */
package org.droidplanner.android.proxy;