/**
 * Contains code and logic related to the {@link org.droidplanner.core.mission.Mission} object.
 */
package org.droidplanner.android.proxy.mission;