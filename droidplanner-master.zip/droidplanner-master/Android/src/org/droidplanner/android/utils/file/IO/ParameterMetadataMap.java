package org.droidplanner.android.utils.file.IO;

import java.util.HashMap;

import org.droidplanner.core.parameters.ParameterMetadata;

public class ParameterMetadataMap extends HashMap<String, ParameterMetadata> {
	private static final long serialVersionUID = 1L;
}
