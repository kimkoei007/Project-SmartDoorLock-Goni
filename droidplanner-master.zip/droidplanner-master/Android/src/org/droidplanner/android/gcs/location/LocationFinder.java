package org.droidplanner.android.gcs.location;

public interface LocationFinder {
	public void enableLocationUpdates();
	public void disableLocationUpdates();
}
