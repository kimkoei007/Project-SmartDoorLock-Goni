/**
 * Contains the different map types implementations.
 */
package org.droidplanner.android.maps.providers;