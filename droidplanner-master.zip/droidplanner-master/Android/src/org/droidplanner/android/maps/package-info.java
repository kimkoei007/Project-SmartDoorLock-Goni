/**
 * Contains maps related code and logic.
 */
package org.droidplanner.android.maps;