/**
 * This package contains code and logic related to the ground control station functionality.
 */
package org.droidplanner.core.gcs;