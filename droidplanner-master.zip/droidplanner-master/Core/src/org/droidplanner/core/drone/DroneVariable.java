package org.droidplanner.core.drone;

public class DroneVariable {
	protected Drone myDrone;

	public DroneVariable(Drone myDrone) {
		this.myDrone = myDrone;
	}
}